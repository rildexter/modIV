// ThirdPage.js
import React, { useState } from 'react';
import { View, Image, TouchableOpacity, StyleSheet, Text } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {styles} from './style';

// Importação das imagens da pasta assets
const image1 = require('../assets/imagem1.png');
const image2 = require('../assets/imagem2.png');
const image3 = require('../assets/imagem3.png');

// Componente funcional para a Terceira Página
const ThirdPage = () => {
  // Hook useNavigation permite a navegação entre as páginas
  const navigation = useNavigation();

  // State para armazenar a imagem atual
  const [currentImage, setCurrentImage] = useState(image1);

  // Função para navegar para a Primeira Página
  const goToFirstPage = () => {
    navigation.navigate('Primeira');
  };

  // Função para trocar a imagem exibida
  const changeImage = (image) => {
    setCurrentImage(image);
  };

  // Retorno do componente
  return (
    <View style={styles.container}>
      {/* Exibição da imagem atual */}
      <Image source={currentImage} style={styles.image} />

      {/* Container de botões para escolher imagens */}
      <View style={styles.buttonContainer}>
        <TouchableOpacity onPress={() => changeImage(image1)} style={styles.imageButton}>
          <Text style={styles.buttonText}>urso 1</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => changeImage(image2)} style={styles.imageButton}>
          <Text style={styles.buttonText}>urso 2</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => changeImage(image3)} style={styles.imageButton}>
          <Text style={styles.buttonText}>urso 3</Text>
        </TouchableOpacity>
      </View>

      {/* Botão para voltar para a Primeira Página */}
      <TouchableOpacity onPress={goToFirstPage} style={styles.button}>
        <Text style={styles.buttonText}>Ir para a Primeira Página</Text>
      </TouchableOpacity>
    </View>
  );
};

// Exportação padrão do componente
export default ThirdPage;
