// FirstPage.js
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {styles} from './style';


// Componente funcional para a Primeira Página
const FirstPage = () => {
  // States para armazenar o nome digitado e a mensagem de boas-vindas
  const [userName, setUserName] = useState('');
  const [welcomeMessage, setWelcomeMessage] = useState('');

  // Hook useNavigation permite a navegação entre as páginas
  const navigation = useNavigation();

  // Função para atualizar o state com o texto digitado no input
  const handleInputChange = (text) => {
    setUserName(text);
  };

  // Função para exibir mensagem de boas-vindas ao pressionar o botão "Enviar"
  const handleSubmit = () => {
    if (userName.trim() !== '') {
      setWelcomeMessage(`Seja bem-vindo, ${userName}!`);
    }
  };

  // Função para navegar para a Segunda Página ao pressionar o botão correspondente
  const goToSecondPage = () => {
    navigation.navigate('Segunda');
  };

  // Função para navegar para a Terceira Página ao pressionar o botão correspondente
  const goToThirdPage = () => {
    navigation.navigate('Terceira');
  };

  // Retorno do componente
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Digite seu nome:</Text>
      
      {/* Input para digitar o nome */}
      <TextInput
        style={styles.input}
        placeholder="Nome"
        value={userName}
        onChangeText={handleInputChange}
      />
      
      {/* Botão para enviar o nome e exibir mensagem de boas-vindas */}
      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Enviar</Text>
      </TouchableOpacity>
      
      {/* Exibição da mensagem de boas-vindas */}
      <Text style={styles.welcomeMessage}>{welcomeMessage}</Text>
      
      {/* Botões para navegar para as outras páginas */}
      <TouchableOpacity style={styles.button} onPress={goToSecondPage}>
        <Text style={styles.buttonText}>Brincando com quadrado</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={goToThirdPage}>
        <Text style={styles.buttonText}>Meu ursinho</Text>
      </TouchableOpacity>
    </View>
  );
};



// Exportação padrão do componente
export default FirstPage;
