// SecondPage.js
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {styles} from './style';

// Componente funcional para a Segunda Página
const SecondPage = () => {
  // Hook useNavigation permite a navegação entre as páginas
  const navigation = useNavigation();

  // State para armazenar a cor do quadrado
  const [squareColor, setSquareColor] = useState('#3498db'); // Cor inicial do quadrado

  // Função para voltar para a Primeira Página
  const goBackToFirstPage = () => {
    navigation.goBack();
  };

  // Função para mudar a cor do quadrado
  const changeColor = (color) => {
    setSquareColor(color);
  };

  // Retorno do componente
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Segunda Página</Text>
      
      {/* Quadrado com cor dinâmica baseada no state squareColor */}
      <View style={[styles.square, { backgroundColor: squareColor }]} />

      {/* Container de botões para escolher cores */}
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[styles.colorButton, { backgroundColor: '#e74c3c' }]}
          onPress={() => changeColor('#e74c3c')}
        />
        <TouchableOpacity
          style={[styles.colorButton, { backgroundColor: '#f39c12' }]}
          onPress={() => changeColor('#f39c12')}
        />
        <TouchableOpacity
          style={[styles.colorButton, { backgroundColor: '#2ecc71' }]}
          onPress={() => changeColor('#2ecc71')}
        />
      </View>

      {/* Botão para voltar para a Primeira Página */}
      <TouchableOpacity style={styles.button} onPress={goBackToFirstPage}>
        <Text style={styles.buttonText}>Voltar para a Primeira Página</Text>
      </TouchableOpacity>
    </View>
  );
};


// Exportação padrão do componente
export default SecondPage;
