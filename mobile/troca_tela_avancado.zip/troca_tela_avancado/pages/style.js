// Estilos CSS para o componente
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'LightGrey',
  },
  text: {
    fontSize: 20,
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 20,
    padding: 10,
  },
  button: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
    buttonContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  colorButton: {
    width: 50,
    height: 50,
    marginRight: 10,
    borderRadius: 5,
  },
  welcomeMessage: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: 'bold',
    color: 'green',
  },
    square: {
    width: 100,
    height: 100,
    marginBottom: 20,
  },
    image: {
    width: 200,
    height: 200,
    marginBottom: 20,
  },
  imageButton: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    marginRight: 10,
  },
});